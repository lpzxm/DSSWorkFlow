?>
<h2>PHP</h2>
<p>PHP es un lenguaje de programación del lado del servidor, ideal para desarrollo web.</p>
<img src="https://www.php.net/images/logos/new-php-logo.png" alt="Logo PHP" width="150">
<iframe width="300" height="200" src="https://www.youtube.com/embed/OK_JCtrrv-c" frameborder="0" allowfullscreen></iframe>
<?php

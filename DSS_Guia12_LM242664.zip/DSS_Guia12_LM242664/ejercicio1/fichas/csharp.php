?>
<h2>C#</h2>
<p>C# es un lenguaje de Microsoft usado para desarrollar en .NET aplicaciones de escritorio, web y móviles.</p>
<img src="https://seeklogo.com/images/C/c-sharp-c-logo-02F17714BA-seeklogo.com.png" alt="Logo C#" width="150">
<iframe width="300" height="200" src="https://www.youtube.com/embed/GhQdlIFylQ8" frameborder="0" allowfullscreen></iframe>
<?php

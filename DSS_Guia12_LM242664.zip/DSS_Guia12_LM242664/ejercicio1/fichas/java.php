?>
<h2>Java</h2>
<p>Java es un lenguaje orientado a objetos ampliamente usado en aplicaciones empresariales y móviles.</p>
<img src="https://upload.wikimedia.org/wikipedia/en/3/30/Java_programming_language_logo.svg" alt="Logo Java" width="150">
<iframe width="300" height="200" src="https://www.youtube.com/embed/eIrMbAQSU34" frameborder="0" allowfullscreen></iframe>
<?php
